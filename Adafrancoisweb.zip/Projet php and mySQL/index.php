<?php 
if (isset($_POST['btn-login'])) {
	
	if (isset($_POST['user']) && isset($_POST['mdp'])) {
		$user = $_POST['user'];
		$mdp = $_POST['mdp'];
		$error ='';

	$nom_serveur = 'localhost';
	$user = 'root';
	$password = ''; 
	$bd_name ='bonbagay';
	$con = mysqli_connect($nom_serveur,$user,$password,$bd_name);
	$req = mysqli_query($con, "SELECT * FROM log where user ='$user' AND mdp ='$mdp'");
	$num_ligne = mysqli_num_rows($req);

	if ($num_ligne > 0) {
		header("Location:InsertionCLient.php");
	}
	else{
		$error = "User ou password incorrects";
		// header("Location:index.php");
	}
}

}

?> 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="design.css">
	<title>Login</title>
</head>
<body>
	<!-- <div class="ada">
      <h1><i>PAGE DE CONNECTION</i></h1>
 	 </div> -->
		<section>
			<h1>Login</h1>
			<?php 
				if (isset($error)) {
					echo $error;
				}	
			?>
			<form action="config.php" method="POST">
				<label>Username</label>
				<input type="text" name="user">
				<label>Password</label>
				<input type="password" name="mdp">
				<input type="submit" value="Login" name="btn-login">
			</form>
		</section>
</body>
</html>