<!DOCTYPE html>
<html>
<head>
	<title>BRAPS'STORE</title>
	<meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="graphic.css">
    <link rel="stylesheet" href="fontawesome-free-5.15.1-web/css/all.min.css" />
		<script language="javascript">
        function move(){

            document.getElementsByClassName("sidebar").classList.toggle('active');
        }
        </script>
</head>
<body>
    <div class="banner">

        
	<nav class="menu">
        <div class="logo">
            <p><div class="kou">BRAPS'</div> <div class="pi">STORE</div></p>
        </div>
       
        
               
                
		<ul>
			<li><a id="client" href="Insertionclient.php"> CLIENT</a></li>
			<li><a id="article"  href="insertionarticles.php"> ARTICLE </a></li>
            <li><a id="achat" href="insertionachat.php" > ACHAT</a></li>
            <li><a  href="index.php">Deconnection</a></li>
            
		</ul>
    </nav>
</div>
</body>
</html>