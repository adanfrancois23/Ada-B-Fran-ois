<?php 
//Syntaxe de connection d'une base a notre page
$con = mysqli_connect("localhost","root","","bonBagay");

if(!$con){
	die('Connexion echoue'.mysqli_connect_error());
}

	
?>