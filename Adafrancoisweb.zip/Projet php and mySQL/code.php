<?php
//Demarrage du systeme
	session_start();
	//lien avec la base de donnes
require 'basecon.php';

if(isset($_POST['supressionclient'])){
	$client_id = mysqli_real_escape_string($con,$_POST['supressionclient']);
	//code pour supprimer un client
	$query = "DELETE FROM client WHERE id ='$client_id'";

		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Supression avec succes";
			header("Location:affichage.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas de supression";
			header("Location:affichage.php");
			exit(0);
		}

}


//Modifier un client
if (isset($_POST['Modifier_client']))
{
	$client_id = mysqli_real_escape_string($con,$_POST['client_id']);

	$nom = mysqli_real_escape_string($con, $_POST['nom']);
	$prenom = mysqli_real_escape_string($con, $_POST['prenom']);
	$adresse = mysqli_real_escape_string($con, $_POST['adresse']);
	$code = mysqli_real_escape_string($con, $_POST['code']);
	$ville = mysqli_real_escape_string($con, $_POST['ville']);
	$pays= mysqli_real_escape_string($con, $_POST['pays']);
	$tel = mysqli_real_escape_string($con, $_POST['tel']);
	//Modification de donnees dans la base
		$query = "UPDATE client SET  nom='$nom',prenom ='$prenom',adresse ='$adresse',code ='$code',ville ='$ville',pays ='$pays',tel ='$tel' where id ='$client_id'";	
		
		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Modification avec succes";
			header("Location:affichage.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas de modification";
			header("Location:affichage.php");
			exit(0);
		}

}
// Ajout d'un client
if (isset($_POST['Ajout_client'])) {
	$nom = mysqli_real_escape_string($con, $_POST['nom']);
	$prenom = mysqli_real_escape_string($con, $_POST['prenom']);
	$adresse = mysqli_real_escape_string($con, $_POST['adresse']);
	$code = mysqli_real_escape_string($con, $_POST['code']);
	$ville = mysqli_real_escape_string($con, $_POST['ville']);
	$pays= mysqli_real_escape_string($con, $_POST['pays']);
	$tel = mysqli_real_escape_string($con, $_POST['tel']);
	//Insertion de donnes dans la base
		$query = "INSERT INTO client(nom,prenom,adresse,code,ville,pays,tel
) VALUE ('$nom','$prenom','$adresse','$code','$ville','$pays','$tel')";

		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Insertion avec succes";
			header("Location:InsertionClient.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas d'insertion";
			header("Location:InsertionClient.php");
			exit(0);
		}
		}
	
		// Partie de l'article

//Ajout article
		if (isset($_POST['Ajout_Article'])) {
	$nom = mysqli_real_escape_string($con, $_POST['nom']);
	$description = mysqli_real_escape_string($con, $_POST['description']);
	$prix = mysqli_real_escape_string($con, $_POST['prix']);
	
	//Insertion de donnes dans la base
		$query = "INSERT INTO article(nom,description,prix) VALUE ('$nom','$description','$prix')";

		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Insertion avec succes";
			header("Location:Insertionarticles.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas d'insertion";
			header("Location:Insertionarticles.php");
			exit(0);
		}
		}

//Modifier article
		if (isset($_POST['Modifier_article']))
{
	$article_reference = mysqli_real_escape_string($con,$_POST['article_reference']);

	$nom = mysqli_real_escape_string($con, $_POST['nom']);
	$description = mysqli_real_escape_string($con, $_POST['description']);
	$prix = mysqli_real_escape_string($con, $_POST['prix']);
	
	//Modification de donnees dans la base
		$query = "UPDATE article SET  nom='$nom',description ='$description',prix ='$prix' where reference ='$article_reference'";	
		
		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Modification avec succes";
			header("Location:affichagearticle.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas de modification";
			header("Location:affichagearticle.php");
			exit(0);
		}

}

//Suprimmer article
if(isset($_POST['supressionarticle'])){
	$article_reference = mysqli_real_escape_string($con,$_POST['supressionarticle']);
	//code pour supprimer un article
	$query = "DELETE FROM article WHERE reference ='$article_reference'";

		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Supression avec succes";
			header("Location:affichagearticle.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas de supression";
			header("Location:affichagearticle.php");
			exit(0);
		}

}

	// Pour les achats
//Ajout achat
	if (isset($_POST['Ajout_Achat'])) {
	$id_client = mysqli_real_escape_string($con, $_POST['id_client']);
	$id_article = mysqli_real_escape_string($con, $_POST['id_article']);
	$qte = mysqli_real_escape_string($con, $_POST['qte']);
	$dates = mysqli_real_escape_string($con, $_POST['dates']);
	//Insertion de donnes dans la base
		$query = "INSERT INTO achat (id_client,id_article,qte,dates)  VALUE ('$id_client','$id_article','$qte','$dates')";

		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Insertion avec succes";
			header("Location:insertionachat.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas d'insertion";
			header("Location:insertionachat.php");
			exit(0);
		}
		}

//Modifier achat
		if (isset($_POST['Modifier_achat']))
{
	$achat_id_achat = mysqli_real_escape_string($con,$_POST['achat_id_achat']);
	$id_client = mysqli_real_escape_string($con, $_POST['id_client']);
	$id_article = mysqli_real_escape_string($con, $_POST['id_article']);
	$qte = mysqli_real_escape_string($con, $_POST['qte']);
	$dates = mysqli_real_escape_string($con, $_POST['dates']);
	
	//Modification de donnees dans la base

		$query = "UPDATE achat SET  qte ='$qte', dates ='$dates' where id_achat ='$achat_id_achat'";	
		
		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Modification avec succes";
			header("Location:affichageachat.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas de modification";
			header("Location:affichageachat.php");
			exit(0);
		}

}

//Suprimmer achat
if(isset($_POST['supressionachat'])){
	$achat_id_achat = mysqli_real_escape_string($con,$_POST['supressionachat']);
	//code pour supprimer un client
	$query = "DELETE FROM achat WHERE id_achat ='$achat_id_achat'";

		$query_run = mysqli_query($con, $query);

		if($query_run){
			$_SESSION['message'] ="Supression avec succes";
			header("Location:affichageachat.php");
			exit(0);
		}
		else{
			$_SESSION['message'] ="Pas de supression";
			header("Location:affichageachat.php");
			exit(0);
		}

}
?>