-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 22 sep. 2022 à 15:47
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP :  7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bonbagay`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat`
--

CREATE TABLE `achat` (
  `id_achat` int(11) NOT NULL,
  `id_client` int(10) NOT NULL,
  `id_article` int(10) NOT NULL,
  `qte` int(30) NOT NULL,
  `dates` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `achat`
--

INSERT INTO `achat` (`id_achat`, `id_client`, `id_article`, `qte`, `dates`) VALUES
(3, 4, 5, 5657, '2022-09-28'),
(8, 2, 3, 345, '2022-09-23'),
(16, 5, 6, 0, '0000-00-00'),
(17, 5, 6, 7, '0000-00-00'),
(19, 5, 6, 10, '0000-00-00'),
(20, 5, 6, 45, '0000-00-00'),
(21, 5, 6, 0, '0000-00-00'),
(22, 5, 6, 30, '0000-00-00'),
(23, 3, 5, 400, '2022-09-10'),
(26, 5, 3, 700, '2022-09-23');

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `reference` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `prix` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`reference`, `nom`, `description`, `prix`) VALUES
(3, 'vklkghfg', 'ada', 43546600),
(4, 'rtytuy', 'dtytuy', 346576),
(5, 'dfgh', 'dsfdgfh', 54657),
(6, 'laptop', 'Rouge', 5000),
(7, 'Telephone', 'Usager', 500);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `adresse` varchar(30) NOT NULL,
  `code` varchar(20) NOT NULL,
  `ville` varchar(30) NOT NULL,
  `pays` varchar(25) NOT NULL,
  `tel` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `adresse`, `code`, `ville`, `pays`, `tel`) VALUES
(2, 'Francois', 'Ada', 'Marassa', '6758854', 'Port-au-Prince', 'Haiti', 43927833),
(3, 'Joseph', 'Madelene', 'Duval', '45678', 'Gros morne', 'Haiti', 345678876),
(5, 'Izidor', 'Shamma', 'Thorbeck', '456789', 'Cayes', 'Haiti', 4567890),
(6, 'Joseph', 'Ficine', 'Guyanne', '3456898', 'hjhkldkhd', 'fdgfgkh', 2147483647),
(10, 'Sainthil', 'Darline', 'Leogane', '43546576', 'Ouest', 'Haiti', 46781716),
(11, 'Philis', 'Dayana', 'Delmas 19', '43546', 'Ouest', 'Haiti', 33478976);

-- --------------------------------------------------------

--
-- Structure de la table `log`
--

CREATE TABLE `log` (
  `idu` int(10) NOT NULL,
  `user` varchar(255) NOT NULL,
  `mdp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `log`
--

INSERT INTO `log` (`idu`, `user`, `mdp`) VALUES
(1, 'root', 'admin1234');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `achat`
--
ALTER TABLE `achat`
  ADD PRIMARY KEY (`id_achat`),
  ADD KEY `idc` (`id_client`),
  ADD KEY `ida` (`id_article`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`reference`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`idu`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `achat`
--
ALTER TABLE `achat`
  MODIFY `id_achat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `reference` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `log`
--
ALTER TABLE `log`
  MODIFY `idu` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `achat`
--
ALTER TABLE `achat`
  ADD CONSTRAINT `ida` FOREIGN KEY (`id_article`) REFERENCES `article` (`reference`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
