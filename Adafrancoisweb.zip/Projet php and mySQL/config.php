<?php 

	
	if (isset($_POST['user']) && isset($_POST['mdp'])) {
		$user = $_POST['user'];
		$mdp = $_POST['mdp'];
		$error ='';

	$nom_serveur = 'localhost';
	$user = 'root';
	$password = ''; 
	$bd_name ='bonbagay';
	$con = mysqli_connect($nom_serveur,$user,$password,$bd_name);
	$req = mysqli_query($con, "SELECT * FROM log where user ='$user' AND mdp ='$mdp'");
	$num_ligne = mysqli_num_rows($req);

	if ($num_ligne > 0) {
		header("Location:Inserionclient.php");
	}
	else{
		
		header("Location:index.php");
	}
}



?> 